import logo from './logo.svg';
import './App.css';
import Midterm from './Midterm';

function App() {
  return (
    <div className="App">
     <Midterm/>
    </div>
  );
}

export default App;
